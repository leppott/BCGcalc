#Supplement 6, OR/WA thermal preference article (11/9/2022)
#Questions? contact Jen.Stamp@tetratech.com

#The thermal preference metric calculator utilizes the BioMonTools R package which is free open-source code available on GitHub (https://github.com/leppott/BioMonTools)
#BioMonTools calculates hundreds of biological metrics (number of taxa, % taxa and % individual) for numerous attributes (not temperature alone)
#here we limit the output to Thermal_Indicator metrics based on the seven thermal preference categories used in the article
#when setting up your input file, use the thermal preference entries from the 'R_Thermal_indicator' column in Appendix A
#cold stenotherm=stenoc;cold=cold;cool=cool;cool/warm=cowa;warm=warm;warm stenotherm=stenow; eurythermal=eurythermal

# STEP 1 (optional) Install BioMonTools if needed
if (!require(remotes)) {install.packages("remotes")}
if (!require(BioMonTools)) {install_github("leppott/BioMonTools", force = TRUE)}

# STEP 2 - Mark redundant taxa (this will add the 'Exclude - TRUE/FALSE' column to the input file)
# these taxa are potentially redundant (non-distinct) and will be excluded from the richness metric calculations

# Packages
library(readxl)
library(knitr)
library(dplyr)
library(BioMonTools)

#set directory
# wd <-'C:/Users/Jen.Stamp/Documents/ThermMetric_TestFiles'
# setwd(wd)
df_data <- read_excel("Input_ti_test_20221010.xlsx")

SampID     <- "SampleID"
TaxaID     <- "TaxaID"
TaxaCount  <- "N_Taxa"
Exclude    <- "Exclude"
TaxaLevels <- c("Phylum"
                , "Class"
                , "Subclass"
                , "Order"
                , "Suborder"
                , "Superfamily"
                , "Family"
                , "SubFamily"
                , "Tribe"
                , "Genus")

Exceptions <- NA

df_example <- markExcluded(df_data
                           , SampID = "SampleID"
                           , TaxaID = "TaxaID"
                           , TaxaCount = "N_Taxa"
                           , Exclude = "Exclude"
                           , TaxaLevels = TaxaLevels
                           , Exceptions = NA)

write.csv(df_example, "Input_ti_test_wExclude_20221010.csv")


# STEP 3 - Calculate Thermal Indicator metrics - take the output csv file coming from the previous step (mark redundant taxa)
# and calculate the thermal indicator metrics


# load data
df_data <- read.csv("Input_ti_test_wExclude_20221010.csv")


fun.MetricNames <- c(
  "ni_total"
  , "nt_total"
  , "nt_ti_stenocold"
  , "nt_ti_cold"
  , "nt_ti_cool"
  , "nt_ti_cowa"
  , "nt_ti_warm"
  , "nt_ti_stenowarm"
  , "nt_ti_eury"
  , "nt_ti_stenocold_cold"
  , "nt_ti_stenocold_cold_cool"
  , "nt_ti_cowa_warm_stenowarm"
  , "nt_ti_warm_stenowarm"
  , "nt_ti_na"
  , "pi_ti_stenocold"
  , "pi_ti_cold"
  , "pi_ti_cool"
  , "pi_ti_cowa"
  , "pi_ti_warm"
  , "pi_ti_stenowarm"
  , "pi_ti_eury"
  , "pi_ti_stenocold_cold"
  , "pi_ti_stenocold_cold_cool"
  , "pi_ti_cowa_warm_stenowarm"
  , "pi_ti_warm_stenowarm"
  , "pi_ti_na"
  , "pt_ti_stenocold"
  , "pt_ti_cold"
  , "pt_ti_cool"
  , "pt_ti_cowa"
  , "pt_ti_warm"
  , "pt_ti_stenowarm"
  , "pt_ti_eury"
  , "pt_ti_stenocold_cold"
  , "pt_ti_stenocold_cold_cool"
  , "pt_ti_cowa_warm_stenowarm"
  , "pt_ti_warm_stenowarm"
  , "pt_ti_na")


# Run Function - will get selection prompt, need to select YES or NO

df.metval <- metric.values(df_data, "bugs"
                           , fun.MetricNames = fun.MetricNames
                           , boo.Shiny = TRUE)

# Ouput
df.metval.select <- df.metval[, c(fun.MetricNames)]

# write results
write.csv(df.metval, "Output_ti_test_20221010.csv")
