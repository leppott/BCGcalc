
###################################*
### Predict Fish-Based Thermal Classes
### Using Benthic Macroinvertebrate Metrics ####
###################################*

# Please see associated report, which is available for download from the OR/WA Shiny app:
# https://tetratech-wtr-wne.shinyapps.io/BCGcalc/




###################################*
### Contact Info ####
###################################*

# Mark Fernandez (mark.fernandez@tetratech.com)




###################################.
### Citations ####
###################################.

# R Citation
citation()
# R Core Team. 2024. R: A language and environment for statistical computing. R Foundation for Statistical Computing,Vienna,Austria. URL https://www.R-project.org/.

citation('BioMonTools')
# Leppott, Erik. 2024. _BioMonTools: Tools for Biomonitoring and Bioassessment_. R package version   1.0.2.9011, <https://github.com/leppott/BioMonTools>.

citation('xgboost')
# Chen T, He T, Benesty M, Khotilovich V, Tang Y, Cho H, Chen K, Mitchell R, Cano I, Zhou T, Li M, Xie J, Lin M, Geng Y, Li Y, Yuan J (2022). _xgboost: Extreme Gradient Boosting_. R package version 1.6.0.1, <https://CRAN.R-project.org/package=xgboost>.

## XGBoost paper
# Chen T and C. Guestrin. 2016. XGBoost: A Scalable Tree Boosting System. 






##################################*
### Load Packages ####
##################################*

# Load packages
# options(digits=7L)
par(mfrow=c(1,1),mar=c(4.5,4.5,1,1),bty='l')
library(data.table)        # [
# library(openxlsx)          # read.xlsx()
library(ggplot2)           # ggplot()
theme_set(theme_classic())
theme_update(legend.position='bottom')
library(xgboost)           # xgb.df()
# library(BioMonTools)       # aaa()
# detach('package:aaa',unload=T)




# Clean workspace
rm(list=ls()); gc()

# Settings
na.strings=c(NA,'NA','N/A','#N/A','','None','<Null>')
seed=27703L
pointsize=9L
txtSize=12L

# Create directories
dir.create('Data')
dir.create('Predictions')

# labels
labelsPretty=function(x){
  formatC(x,digits=NULL,big.mark=',',format='fg')
}

# Set arguments
formals(melt.data.table)$na.rm=T
formals(melt.data.table)$variable.factor=F
formals(dcast.data.table)$fill=NA
formals(dcast.data.table)$value.var='value'
formals(dcast.data.table)$na.rm=T
formals(fread)$sep=','
formals(fread)$skip=0
formals(fread)$header=T
formals(fread)$check.names=T
formals(fread)$na.strings=na.strings
formals(png)$units='in'
formals(png)$res=300
formals(png)$type='cairo'
formals(png)$pointsize=pointsize
formals(expand.grid)$KEEP.OUT.ATTRS=F
formals(expand.grid)$stringsAsFactors=F
formals(rbindlist)$use.names=T
formals(rbindlist)$fill=T
# formals(read.xlsx)$check.names=T
# formals(read.xlsx)$na.strings=na.strings




###################################*
### Loop Variables ####
###################################*

# vars
rm(vars,varsLab,varsTrans)
vars=c('nt_ti_stenocold','nt_ti_cold','nt_ti_cool','nt_ti_warm','nt_ti_stenowarm','nt_ti_eury','nt_ti_cowa',
       'pi_ti_stenocold','pi_ti_cold','pi_ti_cool','pi_ti_warm','pi_ti_stenowarm','pi_ti_eury','pi_ti_cowa',
       'pt_ti_stenocold','pt_ti_cold','pt_ti_cool','pt_ti_warm','pt_ti_stenowarm','pt_ti_eury','pt_ti_cowa')
# varsLog=vars # NOT NEEDED
varsLab=c('# of Cold Stenotherm Taxa','# of Cold Taxa','# of Cool Taxa','# of Warm Taxa','# of Warm Stenotherm Taxa','# of Eurythermal Taxa','# of Cool/Warm Taxa',
          '% of Cold Stenotherm Individuals','% of Cold Individuals','% of Cool Individuals','% of Warm Individuals','% of Warm Stenotherm Individuals','% of Eurythermal Individuals','% of Cool/Warm Individuals',
          '% of Cold Stenotherm Taxa','% of Cold Taxa','% of Cool Taxa','% of Warm Taxa','% of Warm Stenotherm Taxa','% of Eurythermal Taxa','% of Cool/Warm Taxa')
varsTrans=rep(F,length(vars))
cbind(varsTrans,vars,varsLab)
length(vars) # 21 benthic metrics

rm(varsAll) # For sorting
varsAll=c('nt_ti_stenocold','nt_ti_cold','nt_ti_cool','nt_ti_warm','nt_ti_stenowarm','nt_ti_eury','nt_ti_cowa',
          'nt_ti_stenocold_cold','nt_ti_stenocold_cold_cool','nt_ti_cowa_warm_stenowarm','nt_ti_warm_stenowarm', # Extra
          'pi_ti_stenocold','pi_ti_cold','pi_ti_cool','pi_ti_warm','pi_ti_stenowarm','pi_ti_eury','pi_ti_cowa',
          'pi_ti_stenocold_cold','pi_ti_stenocold_cold_cool','pi_ti_cowa_warm_stenowarm','pi_ti_warm_stenowarm', # Extra
          'pt_ti_stenocold','pt_ti_cold','pt_ti_cool','pt_ti_warm','pt_ti_stenowarm','pt_ti_eury','pt_ti_cowa',
          'pt_ti_stenocold_cold','pt_ti_stenocold_cold_cool','pt_ti_cowa_warm_stenowarm','pt_ti_warm_stenowarm') # Extra
length(varsAll) # 33

rm(varsExtra)
varsExtra=setdiff(varsAll,vars)
length(varsExtra) # 12





###################################*
### Load Data ####
###################################*

# Load trained XGBoost model
rm(fit)
fit=readRDS('fit.rds')
# Note: Model was trained on data from Washington and Oregon state. 
# Application of the model outside of the PacNW has not yet been tested. 

# Load user bug metric data
rm(df)
df=fread('Data/TestDataset.csv') # Replace with user csv
nrow(df) # 3501

# Check fields
rm(tmp)
tmp=setdiff(vars,names(df))
if(length(tmp)>0) stop('Missing 1 or more required benthic macroinvertebrate fields')

# extraFields
rm(extraFields)
extraFields=setdiff(names(df),c('SampleID',varsAll))
length(extraFields) # 4

# dfLong - For summary stats
rm(dfLong)
dfLong=melt(df,measure.vars=vars)
# dfLong[,.N,by=variable]
nrow(dfLong) # 73521





###################################*
### Summary Stats ####
###################################*

# All
rm(tmp)
tmp=dfLong[,.(.N,
          Min=min(value),
          P10=quantile(value,0.10),
          P25=quantile(value,0.25),
          Median=median(value),
          Mean=mean(value),
          SD=sd(value),
          P75=quantile(value,0.75),
          P90=quantile(value,0.90),
          Max=max(value)),
       by=.(variable)]
nrow(tmp) # 21
setorder(tmp,variable)
fwrite(tmp,'Predictions/SummaryStats.csv')




###################################*
### Predictions ####
###################################*

# probs
rm(probs)
probs=c('Prob_Class0','Prob_Class1','Prob_Class2','Prob_Class3','Prob_Class4','Prob_Class5')

# yhatProb
rm(tmp)
setorder(df,SampleID)
tmp=as.matrix(df[,..vars])
tmp=predict(fit,newdata=tmp,reshape=T)
colnames(tmp)=probs
# head(tmp)

# Merge
df[,':='(Prob_Class0=NULL,Prob_Class1=NULL,Prob_Class2=NULL,Prob_Class3=NULL,Prob_Class4=NULL,Prob_Class5=NULL)]
df=cbind(df,tmp)

# ClassNum_1st
tmp=max.col(tmp) # Convert prob to class
range(tmp) # 1 6
tmp=tmp-1 # Reset index to zero
df[,ClassNum_1st:=NA_integer_]
df[,ClassNum_1st:=tmp]

# ClassNum_2nd
df[,ClassNum_2nd:=NA_integer_]
df[,ClassNum_2nd:=apply(.SD,1,function(x) which(rank(x)==(length(probs)-1))),.SDcols=probs]
range(df$ClassNum_2nd) # 1 6
df[,ClassNum_2nd:=ClassNum_2nd-1] # Reset index to zero

# Class1st_Prob & 2nd
df[,':='(Class1st_Prob=NA_real_,Class2nd_Prob=NA_real_)]
df[,Class1st_Prob:=apply(.SD,1,FUN=max),.SDcols=probs]
df[,Class2nd_Prob:=apply(.SD,1,function(x) x[which(rank(x)==(length(probs)-1))]),.SDcols=probs]

# ClassNum_Diff & Prob_Diff
df[,':='(ClassNum_Diff=NA_integer_,Prob_Diff=NA_real_)]
df[,ClassNum_Diff:=ClassNum_1st-ClassNum_2nd]
df[,Prob_Diff:=Class1st_Prob-Class2nd_Prob]

# Unclear - 1st and 2nd ClassNarr_Fish is more than 1 class apart
df[,Unclear:=0L]
df[abs(ClassNum_Diff)>1,Unclear:=1]
df[,.N,by=Unclear]

# Leaning
df[,Leaning:=NA_character_]
df[ClassNum_Diff>0,Leaning:='Cooler']
df[ClassNum_Diff<0,Leaning:='Warmer']
df[,.N,by=Leaning]

# Tie
tie=0.015
df[,Tie:=0L]
df[abs(Prob_Diff)<tie,Tie:=1]
df[,.N,by=Tie]

## Overwrite Leaning
# df[Tie==1,Leaning:=NA] # Not done

# ClassNum_Fish
df[,ClassNum_Fish:=as.numeric(ClassNum_1st)]
df[Tie==1 & Leaning=='Cooler',ClassNum_Fish:=ClassNum_Fish-0.5]
df[Tie==1 & Leaning=='Warmer',ClassNum_Fish:=ClassNum_Fish+0.5]
df[,.N,by=ClassNum_Fish]

# Overwrite ClassNum_Fish when the Unclear
df[Unclear==1,ClassNum_Fish:=99]

# classLUT
rm(classLUT)
classLUT=data.table(ClassNum_Fish=c(seq(0,5,by=0.5),99),
                    ClassNarr_Fish=c('BullTrout (MWMT <12 C)',
                                     'TIE BullTrout - CoreCold (MWMT < 12-15.9 C)',
                                     'CoreCold (MWMT 12-15.9 C)',
                                     'TIE CoreCold - SpawningRearing (MWMT 12-17.9 C)',
                                     'SpawningRearing (MWMT 16-17.9 C)',
                                     'TIE SpawningRearing - Migration (MWMT 16-19.9 C)',
                                     'Migration (MWMT 18-19.9 C)',
                                     'TIE Migration - Warm (MWMT 18-22.9 C)',
                                     'Warm (MWMT 20-22.9 C)',
                                     'TIE Warm - VeryWarm (MWMT 20 > 23 C)',
                                     'VeryWarm (MWMT >=23 C)',
                                     'Unclear'))
nrow(classLUT) # 12

# Join
df[,ClassNarr_Fish:=NULL]
intersect(names(df),names(classLUT)) # ClassNum_Fish
df=merge(df,classLUT,by=c('ClassNum_Fish'),all.x=T) # Left join

# Sort fields
rm(tmp,tmp1)
tmp=c('SampleID',extraFields,varsAll,probs,
      'ClassNarr_Fish','ClassNum_Fish','Leaning','Prob_Diff','Tie','Unclear',
      'ClassNum_1st','Class1st_Prob','ClassNum_2nd','Class2nd_Prob','ClassNum_Diff')
tmp1=setdiff(names(df),tmp)
if(length(tmp1)>0) warning("Check for missing fields in 'Predictions.csv'")

# Check if missing unused benthic metrics
tmp1=setdiff(varsExtra,names(df))
if(length(tmp1)>0){
  tmp=setdiff(tmp,tmp1)
}
df=df[,..tmp]

# Export
setorder(df,SampleID)
fwrite(df,'Predictions/Predictions.csv')





###################################*
### Plots ####
###################################*

# Barplot of differences
rm(tmp)
tmp=df[,.N,by=ClassNum_Diff]
png('Predictions/Differences.png',width=6.5,height=5.5)
ggplot(tmp,aes(y=N,x=ClassNum_Diff))+
  geom_hline(yintercept=0,color='darkgrey')+
  geom_col()+
  scale_y_continuous(labels=labelsPretty)+
  scale_x_continuous(breaks= -6:5)+
  labs(y='Count',x='Difference (1st minus 2nd)',title=NULL)+
  theme(text=element_text(size=txtSize))
dev.off()

# Barplot of FishClasses
rm(tmp)
tmp=df[,.N,by=ClassNum_Fish]
png('Predictions/FishClasses.png',width=6.5,height=5.5)
ggplot(tmp[ClassNum_Fish<10,],aes(y=N,x=ClassNum_Fish))+
  geom_hline(yintercept=0,color='darkgrey')+
  geom_col()+
  # geom_histogram()+
  scale_y_continuous(labels=labelsPretty)+
  scale_x_continuous(breaks=0:10)+
  labs(y='Count',x='Fish Class',title=NULL)+
  theme(text=element_text(size=txtSize))
dev.off()





























